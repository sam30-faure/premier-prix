import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        argile: {
          DEFAULT: "#C1653C",
          dark: "#9E4F2C",
        },
        sauge: {
          DEFAULT: "#3F5443",
          dark: "#2E3F32",
        },
        ivoire: "#F7F4EE",
        encre: "#1C2620",
      },
      fontFamily: {
        titre: ["var(--font-fraunces)"],
        corps: ["var(--font-public-sans)"],
      },
    },
  },
  plugins: [],
};

export default config;
