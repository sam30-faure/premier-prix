export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center px-6 py-24 text-center">
      <span className="mb-6 rounded-full bg-sauge/10 px-4 py-1 text-sm font-medium text-sauge">
        Bientôt disponible
      </span>
      <h1 className="max-w-2xl font-titre text-4xl font-semibold leading-tight text-encre sm:text-5xl">
        Une estimation de prix immédiate, directement sur ton site.
      </h1>
      <p className="mt-6 max-w-xl text-lg text-encre/70">
        Premier Prix arrive bientôt pour les professionnels de l&rsquo;immobilier.
        Fini les visiteurs qui ferment l&rsquo;onglet faute de réponse.
      </p>
      <div className="mt-10 rounded-2xl bg-argile px-8 py-4 font-corps text-base font-semibold text-ivoire shadow-sm">
        Ouverture prochaine
      </div>
    </main>
  );
}
