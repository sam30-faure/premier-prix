import type { Metadata } from "next";
import { Fraunces, Public_Sans } from "next/font/google";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  weight: ["500", "600", "700"],
});

const publicSans = Public_Sans({
  subsets: ["latin"],
  variable: "--font-public-sans",
  weight: ["400", "500", "600"],
});

export const metadata: Metadata = {
  title: "Premier Prix — l'estimation immédiate sur ton site",
  description:
    "Donne à tes visiteurs une fourchette de prix immédiate, et récupère leurs coordonnées pour un devis précis. Fait pour les professionnels de l'immobilier.",
  openGraph: {
    title: "Premier Prix — l'estimation immédiate sur ton site",
    description:
      "Donne à tes visiteurs une fourchette de prix immédiate, et récupère leurs coordonnées pour un devis précis.",
    locale: "fr_FR",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr" className={`${fraunces.variable} ${publicSans.variable}`}>
      <body className="font-corps">{children}</body>
    </html>
  );
}
